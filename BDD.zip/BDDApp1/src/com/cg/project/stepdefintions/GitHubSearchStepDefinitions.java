package com.cg.project.stepdefintions;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GitHubSearchStepDefinitions {
	@Given("^User is on GitHub LoginPage$")
	public void user_is_on_GitHub_LoginPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enter Correct username and password$")
	public void user_enter_Correct_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user should successfully Signin on his Github Account$")
	public void user_should_successfully_Signin_on_his_Github_Account() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enter wrong username and password$")
	public void user_enter_wrong_username_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'InCorrect username and password' Message should display$")
	public void incorrect_username_and_password_Message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enter correct username and wrong password$")
	public void user_enter_correct_username_and_wrong_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Correct username with wrong password' Message should display$")
	public void correct_username_with_wrong_password_Message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
